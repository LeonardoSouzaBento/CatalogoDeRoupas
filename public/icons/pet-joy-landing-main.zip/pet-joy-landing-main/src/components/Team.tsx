import { User } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const teamMembers = [
  {
    name: "Ana Paula",
    role: "Groomer especializada",
    experience: "4 anos de experiência, ama shih tzus e vira-latas",
  },
  {
    name: "Carlos Henrique",
    role: "Esteticista de cães e gatos",
    experience: "6 anos trabalhando com pets de todas as raças",
  },
  {
    name: "Juliana Alves",
    role: "Atendimento e carinhos ilimitados",
    experience: "Especialista em criar ambiente acolhedor para os pets",
  },
  {
    name: "Dra. Sofia Mendes",
    role: "Veterinária parceira",
    experience: "10 anos de experiência em clínica veterinária",
  },
];

const Team = () => {
  return (
    <section className="section-container">
      <div className="text-center mb-16 fade-in">
        <h2 className="text-foreground mb-4">Quem cuida do meu pet?</h2>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Profissionais treinados, dedicados e apaixonados por animais
        </p>
        <div className="w-24 h-1 bg-primary mx-auto rounded-full mt-6" />
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {teamMembers.map((member, index) => (
          <Card
            key={index}
            className="border-none shadow-lg hover:shadow-xl transition-all hover:-translate-y-2 slide-up"
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <CardContent className="p-6 text-center">
              <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center mx-auto mb-6">
                <User className="w-12 h-12 text-white" />
              </div>
              <h3 className="text-xl font-bold text-card-foreground mb-2">
                {member.name}
              </h3>
              <p className="text-primary font-semibold mb-3">{member.role}</p>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {member.experience}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
};

export default Team;
