import { Heart, MapPin, Phone, Clock } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-foreground text-background">
      <div className="section-container py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Logo and Description */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Heart className="w-8 h-8 text-secondary" fill="currentColor" />
              <span className="text-2xl font-bold">Pet Shop</span>
            </div>
            <p className="text-background/80 leading-relaxed">
              Cuidado e carinho para o seu melhor amigo. Seu pet merece o melhor!
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold text-lg mb-4">Links Úteis</h3>
            <ul className="space-y-2 text-background/80">
              <li>
                <a href="#services" className="hover:text-secondary transition-colors">
                  Nossos Serviços
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-secondary transition-colors">
                  Sobre Nós
                </a>
              </li>
              <li>
                <a href="#team" className="hover:text-secondary transition-colors">
                  Nossa Equipe
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-secondary transition-colors">
                  Contato
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-bold text-lg mb-4">Contato</h3>
            <ul className="space-y-3 text-background/80">
              <li className="flex items-start gap-2">
                <Phone className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <span>(XX) XXXXX-XXXX</span>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <span>Rua Exemplo, 123 – Centro<br />Sua Cidade</span>
              </li>
            </ul>
          </div>

          {/* Opening Hours */}
          <div>
            <h3 className="font-bold text-lg mb-4">Horário</h3>
            <ul className="space-y-2 text-background/80">
              <li className="flex items-start gap-2">
                <Clock className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <div>
                  <p>Seg a Sex: 9h às 18h</p>
                  <p>Sábados: 8h às 14h</p>
                </div>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-background/20 text-center text-sm text-background/60">
          <p>© {currentYear} Pet Shop. Todos os direitos reservados.</p>
          <p className="mt-2">CNPJ: XX.XXX.XXX/XXXX-XX</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
