import vetImage from "@/assets/vet-with-pet.jpg";

const About = () => {
  return (
    <section className="section-container bg-section-medium">
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        {/* Text Content */}
        <div className="space-y-6 fade-in">
          <div>
            <h2 className="text-foreground mb-4">Quem somos</h2>
            <div className="w-24 h-1 bg-primary rounded-full mb-6" />
          </div>
          
          <p className="text-lg text-muted-foreground leading-relaxed">
            Somos um pet shop que acredita que cada animal merece cuidado, afeto e atenção especial.
          </p>
          
          <p className="text-lg text-muted-foreground leading-relaxed">
            Aqui, seu pet é tratado como parte da família. Nossa equipe é treinada para oferecer 
            o melhor atendimento, sempre com muito carinho e dedicação.
          </p>

          <div className="flex flex-wrap gap-6 pt-4">
            <div className="flex-1 min-w-[150px]">
              <div className="text-4xl font-bold text-primary mb-2">5+</div>
              <div className="text-muted-foreground">Anos de experiência</div>
            </div>
            <div className="flex-1 min-w-[150px]">
              <div className="text-4xl font-bold text-primary mb-2">1000+</div>
              <div className="text-muted-foreground">Pets atendidos</div>
            </div>
            <div className="flex-1 min-w-[150px]">
              <div className="text-4xl font-bold text-primary mb-2">100%</div>
              <div className="text-muted-foreground">Amor e dedicação</div>
            </div>
          </div>
        </div>

        {/* Image */}
        <div className="fade-in">
          <div className="rounded-3xl overflow-hidden shadow-lg hover:shadow-hover-lg transition-all">
            <img
              src={vetImage}
              alt="Veterinária segurando um pet"
              className="w-full h-full object-cover bg-muted"
              loading="lazy"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
