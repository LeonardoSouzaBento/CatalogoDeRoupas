import Hero from "@/components/Hero";
import Differentials from "@/components/Differentials";
import Services from "@/components/Services";
import About from "@/components/About";
import Contact from "@/components/Contact";
import Team from "@/components/Team";
import History from "@/components/History";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Hero />
      <Differentials />
      <Services />
      <About />
      <Contact />
      <Team />
      <History />
      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default Index;
