import { Droplet, Scissors, Cat, Package, Sparkles, Truck } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const services = [
  {
    icon: Droplet,
    title: "Banho completo",
    description: "Higiene com produtos especiais para pele e pelos",
    color: "text-blue-500",
    bgColor: "bg-blue-50",
  },
  {
    icon: Scissors,
    title: "Tosa e estética",
    description: "Tesoura, máquina, laços, hidratação e finalização",
    color: "text-secondary",
    bgColor: "bg-secondary/10",
  },
  {
    icon: Cat,
    title: "Banho e Tosa para gatos",
    description: "Ambiente seguro e sem estresse",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    icon: Package,
    title: "Pacote de cuidados regulares",
    description: "Programas mensais com preço especial",
    color: "text-purple-500",
    bgColor: "bg-purple-50",
  },
  {
    icon: Sparkles,
    title: "Spa Pet",
    description: "Hidratação, limpeza de ouvidos, corte de unhas, perfume",
    color: "text-pink-500",
    bgColor: "bg-pink-50",
  },
  {
    icon: Truck,
    title: "Transporte pet",
    description: "Vamos até você buscar e levar seu pet com segurança",
    color: "text-green-500",
    bgColor: "bg-green-50",
  },
];

const Services = () => {
  return (
    <section className="section-container">
      <div className="text-center mb-16 fade-in">
        <h2 className="text-foreground mb-4">Nossos serviços</h2>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Tudo o que seu amigo precisa para ficar bonito, saudável e feliz.
        </p>
        <div className="w-24 h-1 bg-primary mx-auto rounded-full mt-6" />
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {services.map((service, index) => (
          <Card
            key={index}
            className="border-none shadow-lg hover:shadow-xl transition-all hover:-translate-y-2 slide-up"
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <CardContent className="p-8 text-center">
              <div className={`w-16 h-16 rounded-2xl ${service.bgColor} flex items-center justify-center mx-auto mb-6`}>
                <service.icon className={`w-8 h-8 ${service.color}`} />
              </div>
              <h3 className="text-xl font-bold text-card-foreground mb-3">
                {service.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {service.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Optional: Veterinary Section */}
      <div className="mt-16 p-8 bg-primary/5 rounded-3xl border-2 border-primary/20 text-center fade-in">
        <h3 className="text-2xl font-bold text-foreground mb-3">
          Avaliações e orientações veterinárias
        </h3>
        <p className="text-muted-foreground">
          Conte com profissionais qualificados para cuidar da saúde do seu pet
        </p>
      </div>
    </section>
  );
};

export default Services;
