import { Heart, Shield, Sparkles, Calendar, Home } from "lucide-react";
import bathingImage from "@/assets/bathing-service.jpg";

const differentials = [
  {
    icon: Heart,
    title: "Equipe apaixonada por animais",
    description: "Profissionais dedicados que tratam cada pet com carinho genuíno",
  },
  {
    icon: Shield,
    title: "Espaço seguro e higienizado",
    description: "Ambiente limpo e protegido para total tranquilidade",
  },
  {
    icon: Sparkles,
    title: "Produtos de alta qualidade",
    description: "Utilizamos apenas as melhores marcas para cuidar do seu pet",
  },
  {
    icon: Calendar,
    title: "Agendamentos flexíveis",
    description: "Horários adaptados à sua rotina com atendimento rápido",
  },
  {
    icon: Home,
    title: "Ambiente acolhedor",
    description: "Seu pet se sente em casa conosco",
  },
];

const Differentials = () => {
  return (
    <section className="section-container bg-section-light">
      <div className="text-center mb-12 fade-in">
        <h2 className="text-foreground mb-4">Por que nossos clientes confiam em nós?</h2>
        <div className="w-24 h-1 bg-primary mx-auto rounded-full" />
      </div>

      <div className="grid lg:grid-cols-2 gap-12 items-center">
        {/* Image */}
        <div className="order-2 lg:order-1 fade-in">
          <div className="rounded-3xl overflow-hidden shadow-2xl">
            <img
              src={bathingImage}
              alt="Pet relaxado durante o banho"
              className="w-full h-full object-cover bg-muted"
              loading="lazy"
            />
          </div>
        </div>

        {/* Differentials List */}
        <div className="order-1 lg:order-2 space-y-6">
          {differentials.map((item, index) => (
            <div
              key={index}
              className="flex gap-4 p-6 bg-card rounded-2xl shadow-sm hover:shadow-lg transition-all hover:scale-[1.02] slide-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <item.icon className="w-6 h-6 text-primary" />
                </div>
              </div>
              <div>
                <h3 className="text-lg font-bold text-card-foreground mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Differentials;
